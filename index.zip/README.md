# plg_content_cgversion_j4
 Display a component version
